/*
 File: scheduler.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "scheduler.H"
#include "thread.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"

//#include <queue.h>
//#include <iostream>





/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   S c h e d u l e r  */
/*--------------------------------------------------------------------------*/
const int READY_QSIZEMAX = 80;   //LET THE MAX SIZE OF FIFO BE 80


Scheduler::Scheduler() {
  
   FRONT=NULL;
   REAR=NULL;
   quantum_handler= 50; //to implement round robin
   total_thread = 1; //total_thread in ready , scheduler assuming idle thread 
  
  Console::puts("Constructed Scheduler.\n");
}







void Scheduler::yield() {
 
 
  //we assume there is one idle thread in queue at any point of time for yield 
 
   
   //thread* tfront = ready_que.front();
  // ready_que.pop();
  qnode* temp_n = new qnode;
    temp_n = FRONT;
    FRONT = FRONT->next;
    Thread *trfront = temp_n->qthread;
    
    total_thread--;
    
    
    Thread::dispatch_to(trfront); 
     delete[] temp_n;
     //dispatch the next ready thread to get cpu so that current thread yields
   Console::puts("Yield has been done\n");
 
 
 
}

void Scheduler::resume(Thread * _thread) {
  
 
  //ready_que.push(*_thread); //push thread to ready queue to resume
  
  qnode* temp_add = new qnode;
  temp_add->qthread = _thread;
  
   if(REAR==NULL || FRONT == NULL){
     FRONT = temp_add;
     REAR = temp_add;
  }
  else{
  REAR->next = temp_add; }
  REAR = temp_add;
  temp_add->next = NULL;
  
  total_thread++;
  Console::puts("Thread has been resumed\n");
  
 
}

void Scheduler::add(Thread * _thread) {
  
   //if(total_thread<READY_QSIZEMAX){
   //ready_que.push(*_thread);
   
   qnode* temp_add = new qnode;
  temp_add->qthread = _thread;
  
  if(REAR==NULL || FRONT == NULL){
     FRONT = temp_add;
     REAR = temp_add;
  }
  else{
  REAR->next = temp_add; }
  
  
  REAR = temp_add; 
  temp_add->next= NULL;
   total_thread++;
   
   Console::puts("Thread has been addded to scheduler\n");
   
   
//}

//else
   //{
  
  //Console::puts("FIFO Scheduler is full\n");
  //}
  }

void Scheduler::terminate(Thread * _thread) {
 
 //int queueloop =0;
 
 
 //while(queueloop<ready_que.size()){
  //thread* newthrd_qtop = ready_que.front();
   
  
 //if(_thread->thread_id == newthd_qtop->thread_id)
// {
  //  ready_que.pop();
    /*total_thread--;
    Console::puts("Thread has been terminated\n");
    
  
 }
 else if (_thread->thread_id != newthd_qtop->thread_id){
   ready_que.pop();
   ready_que.push(*newthrd_qtop);
   
 
 }
 */
 
delete[] _thread;
Console::puts("Thread is deleted\n");



}


