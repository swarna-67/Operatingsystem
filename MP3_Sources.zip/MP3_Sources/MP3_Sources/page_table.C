#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"

#define PAGE_DIRECTORY_FRAME_SIZE 1

#define PAGE_PRESENT        0x01
#define PAGE_WRITE          0x10
#define PAGE_LEVEL          0x100

#define PD_SHIFT            22    
#define PT_SHIFT            12

#define PDE_MASK            0xFFFFF000
#define PT_MASK             0x3FF



PageTable * PageTable::current_page_table = NULL; // initalize current page table to null
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;




void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
 
    kernel_mem_pool = _kernel_mem_pool;     // initalize kernel_mem_pool, process_mem_pool, shared_size
    process_mem_pool = _process_mem_pool;
    shared_size = _shared_size;
 
 
   Console::puts("Initialized Paging System\n");
}

PageTable::PageTable()
{
  
    page_directory = (unsigned long *)(kernel_mem_pool->get_frames
                                (PAGE_DIRECTORY_FRAME_SIZE)*PAGE_SIZE);

    unsigned long masked_address = 0;
    unsigned long * direct_map_page_table = (unsigned long *)(kernel_mem_pool->get_frames
                                                        (PAGE_DIRECTORY_FRAME_SIZE)*PAGE_SIZE);  //pointer to direct map table is set by multiplying total frames from kernel pool with page directory frame size

    unsigned long shared_frm = ( PageTable::shared_size / PAGE_SIZE); //total number of shared frames is total shared size/ page size
    
    
    
    for(int i = 0; i < shared_frm; i++) {   // we set the shared memory page table here 
        direct_map_page_table[i] = masked_address | PAGE_WRITE | PAGE_PRESENT ;  
        masked_address = masked_address + PAGE_SIZE;  //eveery entry is of page size hence increment accordingly 
    }

    // first page directory  entry is set for shared memory
    page_directory[0] = (unsigned long)direct_map_page_table | PAGE_WRITE | PAGE_PRESENT;

    masked_address = 0;
    // non shared memory page entries are masked zero since we dont consider them intially
    for(int i = 1; i< shared_frm; i++) {
        page_directory[i] = masked_address | PAGE_WRITE;
    }

  
  
   Console::puts("Constructed Page Table object\n");
}


void PageTable::load()
{
  
  
   current_page_table = this;    //points to the current page table
    write_cr3((unsigned long)page_directory); //load the page table base register with page directory addresss
    Console::puts("Loaded page table\n");
  
  
}

void PageTable::enable_paging()
{
 
 paging_enabled = 1; //set paging_enabled bit to 1 

   
    write_cr0(read_cr0() | 0x80000000);  //read the cro reg and use only the msb bit to check if paging enabled bit is set 
    
    Console::puts("Enabled paging\n");
    
}
 
 
 

void PageTable::handle_fault(REGS * _r)
{
 
 // page directory base address is pointed to by the current_pg_dir pointer 
    unsigned long * current_pg_dir = (unsigned long *) read_cr3();
  
  
    //  page address will be the address where fault occurred
    unsigned long page_address = read_cr2();   // virtual address that caused the fault (CR2 register) 
    unsigned long PD_address   = page_address >> PD_SHIFT;
    unsigned long PT_address   = page_address >> PT_SHIFT;

    unsigned long * page_table = NULL;
    unsigned long error_code = _r->err_code;

    unsigned long mask_addr = 0;

    /*
     * --10bits for  the PD-- --10bits for the Page Table -- --12bit is offset--
     * 0000 0000 00       0000 0000 00      00 0000 0000
     */
 
 
  if ((error_code & PAGE_PRESENT) == 0 ) {
        if ((current_pg_dir[PD_address] & PAGE_PRESENT ) == 1) {  //fault in the Page table
            page_table = (unsigned long *)(current_pg_dir[PD_address] & PDE_MASK);
            page_table[PT_address & PT_MASK] = (PageTable::process_mem_pool->get_frames
                                                (PAGE_DIRECTORY_FRAME_SIZE)*PAGE_SIZE) | PAGE_WRITE | PAGE_PRESENT ;

        } else {
            current_pg_dir[PD_address] = (unsigned long) ((kernel_mem_pool->get_frames
                                                (PAGE_DIRECTORY_FRAME_SIZE)*PAGE_SIZE) | PAGE_WRITE | PAGE_PRESENT);

            page_table = (unsigned long *)(current_pg_dir[PD_address] & PDE_MASK);

            for (int i = 0; i<1024; i++) {
                page_table[i] = mask_addr | PAGE_LEVEL ; // set the pages as user page
            }

            page_table[PT_address & PT_MASK] = (PageTable::process_mem_pool->get_frames
                                                (PAGE_DIRECTORY_FRAME_SIZE)*PAGE_SIZE) | PAGE_WRITE | PAGE_PRESENT ;

        }
    }

  
 
 
  Console::puts("handled page fault\n");
}





