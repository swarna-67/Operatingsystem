/*
     File        : blocking_disk.c

     Author      : 
     Modified    : 

     Description : 

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "utils.H"
#include "console.H"
#include "blocking_disk.H"
#include "simple_disk.H"
#include "scheduler.H"
#include "thread.H"

extern Scheduler * SYSTEM_SCHEDULER;


/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

BlockingDisk::BlockingDisk(DISK_ID _disk_id, unsigned int _size) 
  : SimpleDisk(_disk_id, _size) {
}

/*--------------------------------------------------------------------------*/
/* SIMPLE_DISK FUNCTIONS */
/*--------------------------------------------------------------------------*/

void BlockingDisk::read(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
 // SimpleDisk::read(_block_no, _buf);
 
  SimpleDisk::issue_operation(DISK_OPERATION::READ, _block_no); //declared it as protected memeber in simple disk base class in order to access it here
   
   
   
   
    bool isreadyread = SimpleDisk::is_ready();
  
  //if the disk is not ready add the thread that wants to perform read by  queueing up on the disk queue and do yield of next thread
  while(!isreadyread){
   if(!isreadyread){
    
    SYSTEM_SCHEDULER->add(Thread::CurrentThread());
    SYSTEM_SCHEDULER->yield();
  
  }
  isreadyread = SimpleDisk::is_ready();
  }
  
  
  int i;
  unsigned short tmpw;
  for (i = 0; i < 256; i++) {
    tmpw = Machine::inportw(0x1F0);
    _buf[i*2]   = (unsigned char)tmpw;
    _buf[i*2+1] = (unsigned char)(tmpw >> 8);
  }



}


void BlockingDisk::write(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
  //SimpleDisk::write(_block_no, _buf);
  
   SimpleDisk::issue_operation(DISK_OPERATION::WRITE, _block_no);
  
  bool isreadywrite = SimpleDisk::is_ready();
  
  //if the disk is not ready add the thread that wants to perform write by  queueing up on the disk queue and do yield of next thread
  while(!isreadywrite){
 if(!isreadywrite){
    
    SYSTEM_SCHEDULER->add(Thread::CurrentThread());
    SYSTEM_SCHEDULER->yield();
  
  }
  isreadywrite =  SimpleDisk::is_ready();
  
 }
  

  int i; 
  unsigned short tmpw;
  for (i = 0; i < 256; i++) {
    tmpw = _buf[2*i] | (_buf[2*i+1] << 8);
    Machine::outportw(0x1F0, tmpw);
  }
  
  
  
  
}
