/*
 File: vm_pool.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "vm_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"
#include "cont_frame_pool.H"
/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   V M P o o l */
/*--------------------------------------------------------------------------*/

VMPool::VMPool(unsigned long  _base_address,
               unsigned long  _size,
               ContFramePool *_frame_pool,
               PageTable     *_page_table) {
   // assert(false);
   
   
   
   base_address = _base_address;
   size = _size;
   frame_pool = _frame_pool;
   page_table = _page_table;
   page_table->register_pool(this);
  pool_struct *pool_region = (pool_struct *)base_address;
   
   pool_region[0].pool_region_start_addr = base_address;
   
   pool_region[0].pool_region_size = PageTable::PAGE_SIZE;
   
   count_pool_region = 1;
   int j =1;
  while ( j <255){
  
  pool_region[j].pool_region_start_addr =0;
  
  pool_region[j].pool_region_size = 0;
   j++;
  
  
  
  }
   
    Console::puts("Constructed VMPool object.\n");
}

unsigned long VMPool::allocate(unsigned long _size) {
   // assert(false);
   
 pool_struct   *pool_region = (pool_struct *)base_address;
   unsigned long required_size_allocation; 
   
   if (_size<PageTable::PAGE_SIZE)
    
    required_size_allocation = PageTable::PAGE_SIZE;
    
    else {
    
    unsigned int size_inpage = _size/ PageTable::PAGE_SIZE;
    
    unsigned long extra_page = (_size % PageTable::PAGE_SIZE> 0) ? PageTable::PAGE_SIZE : 0;
    
    required_size_allocation = size_inpage * (PageTable::PAGE_SIZE) + extra_page;
    
    }
    Console::puts("Size required of allocation is computed \n");
    
    unsigned int k = 1;
    
    while (k < 255 ){
    
    
    if ( pool_region[k].pool_region_start_addr!=0)
    {
    k++;
    }
    else{
    
    
    pool_region[k].pool_region_size = required_size_allocation;
    
    pool_region[k].pool_region_start_addr = pool_region[k-1].pool_region_start_addr + pool_region[k-1].pool_region_size;
    
    count_pool_region = count_pool_region + 1;
    break;
    
    
    
    
    
    }
    
    }
    
    Console::puts("Allocated region of memory.\n");
   
   return pool_region[k].pool_region_start_addr;
   
   
}

void VMPool::release(unsigned long _start_address) {
 pool_struct  *pool_region = (pool_struct *)base_address;
   
   // assert(false);
   
   
  // int l = 1;
   
   int found;
   for (unsigned int count  = 1; count<256; count++){
   
   if (pool_region[count].pool_region_start_addr != _start_address)
    {
   
      continue;
    }
    
    else {
     
      found =count;
      Console::puts("tHE REGION TO release is found\n");
      break;    
    
    }
   
   }
   
   //freeing the pages
   
   int total_number_of_page;
   
   total_number_of_page = pool_region[found].pool_region_size / PageTable::PAGE_SIZE;
   
   
   for(int i =0;i<total_number_of_page;i++){
   
    
      page_table->PageTable::free_page(pool_region[found].pool_region_start_addr);
      
      pool_region[found].pool_region_start_addr = pool_region[found].pool_region_start_addr + PageTable::PAGE_SIZE;
   
   }
   
   
   //free the region
   
   for (int k = found;k<255; k++){
   
     
   pool_region[k].pool_region_size = pool_region[k+1].pool_region_size;
   
   pool_region[k].pool_region_start_addr = pool_region[k+1].pool_region_start_addr;
   count_pool_region = count_pool_region -1;
   }
   
    Console::puts("Released region of memory.\n");
}

bool VMPool::is_legitimate(unsigned long _address) {
  //  assert(false);
  
  int temp1 = 0;
  
  int temp2 =0 ;
  
  if(base_address > _address )
   temp1 =1;
   
   if(base_address + size < _address)
   
   temp2 = 1;
   
    Console::puts("Checked whether address is part of an allocated region.\n");
  if ( (temp1 ==1 ) || (temp2 ==1 ))
  return false;
  else
  return true;
  
  
  
  
  
}

