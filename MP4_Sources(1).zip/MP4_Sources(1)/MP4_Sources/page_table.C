#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"
#include "cont_frame_pool.H"

PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;
VMPool *PageTable::vm_pool_array[];
unsigned int PageTable::registerd_vmpool_count =255;

void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
 
 
    PageTable::kernel_mem_pool = _kernel_mem_pool;
    PageTable::process_mem_pool = _process_mem_pool;
    PageTable::shared_size = _shared_size;
    
   
 
    Console::puts("Initialized Paging System\n");
}

PageTable::PageTable()
{
    //one frame for directory page
    
    page_directory = (unsigned long *)((process_mem_pool->get_frames(1))*PAGE_SIZE);
    
    
   unsigned long  *page_table = (unsigned long  *)((process_mem_pool->get_frames(1))*PAGE_SIZE);
   //RECURSIVE SETUP USING LAST ENTRY OF PAGE DIRECTORY 
   page_directory[1023] = (unsigned long)page_directory | 0x011; //to point to page directory itself;
   
   
   unsigned long  addr = 0; 
   
   for(int k=1; k<1023;k++){
    
     page_directory[k] = addr| 0x010;
   
   
   }
   
   page_directory[0] = (unsigned long) page_table;
   
   
   
   page_directory[0] = page_directory[0] | 0x011;
   
  Console::puts("Page directory entry constructed\n");
  unsigned int i=0; 
  while(i<1024){
   
    page_table[i] = addr|0x010;
    addr = addr + PAGE_SIZE;
    i++;
  }
    
    Console::puts("Constructed Page Table object\n");
}


void PageTable::load()
{
   
   
   current_page_table = this;
   
   write_cr3((unsigned long)page_directory);
   
   
    Console::puts("Loaded page table\n");
}

void PageTable::enable_paging()
{
   // assert(false);
   
    
   
   
   write_cr0( read_cr0() | 0x80000000);
   
   PageTable::paging_enabled = 1;
   
    Console::puts("Enabled paging\n");
}

void PageTable::handle_fault(REGS * _r)
{
    //assert(false);
     
     
     unsigned long page_directory_entry;
     unsigned long page_table_entry;
     unsigned long * page_directory_pointer;
  unsigned long * page_table_pointer;
  
     
    //find the address triggering the page fault
    
    unsigned long addr_causing_pgfault = read_cr0();
    //unsigned int count_registered_pool;
   
  
  page_directory_pointer = (unsigned long*)(0xFFFFF000);
    
  
    for(unsigned int i=0; i< registerd_vmpool_count;i++){
    
    
            if(!vm_pool_array[i]->VMPool::is_legitimate(addr_causing_pgfault))
            {
             
             Console::puts("The memory reference is invalid\n");
             assert(false);
             
            
            }
    
    }
    
    unsigned long PDE = addr_causing_pgfault;
    page_directory_entry = addr_causing_pgfault>>22;
    page_table_entry = ((PDE >>12) & 0x003FF);
    page_table_pointer = (unsigned long*)((0xFFC00000)| page_directory_entry<<12);
    
    //MARK THE ENTRY IN PAGE TABLE
     if ((page_table_pointer[page_table_entry] & 0x01)==0)
   {
   
     page_table_pointer[page_table_entry] = ((unsigned long)(process_mem_pool->get_frames(1)*PAGE_SIZE)) | 0X011;
   }
    
    
    
    
   //if entry not there in page directory 
    if((page_directory_pointer[page_directory_entry]& 0x01)==0)
    {
     page_directory_pointer[page_directory_entry] = ((unsigned long)(process_mem_pool->get_frames(1)*PAGE_SIZE)) | 0x011;
     
    
    }
    
  
    
    Console::puts("handled page fault\n");
}

void PageTable::register_pool(VMPool * _vm_pool)
{
   unsigned int j=0;
   int max_vm_pool = 256;
   while( j <max_vm_pool){
   
     if(vm_pool_array[j]!=0)
        j++;
     else 
      
     break; 
     
   
   }
   vm_pool_array[j] = _vm_pool;
   registerd_vmpool_count++;
    
  Console::puts("registered VM pool\n");
}

void PageTable::free_page(unsigned long _page_no) {
  //  assert(false);
  
  
  
  unsigned long index_to_page_directory = ((_page_no)& 0xFFC00000)>>22;
  
  unsigned long *page_table_p = (unsigned long*)( (index_to_page_directory<<12) | (0xFFC00000));
  
  unsigned long frame_number;
  
  unsigned long index_to_pg_tbl = ((_page_no) & (0x003FF000))>>12;
  
  
  frame_number = page_table_p[index_to_pg_tbl] / PAGE_SIZE;
  
  
  //release the frame associated
  process_mem_pool->release_frames(frame_number);
  Console::puts("Frame has been released\n");
  page_table_p[index_to_pg_tbl] = page_table_p[index_to_pg_tbl] | 0x010;
  
  // need to flush the entries in tlb as well when we release 
  
   write_cr3((unsigned long)page_directory);
  
    Console::puts("freed page\n");
}
