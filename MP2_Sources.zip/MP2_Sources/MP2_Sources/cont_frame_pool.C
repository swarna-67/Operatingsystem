/*
 File: ContFramePool.C
 
 Author:
 Date  : 
 
 */

/*--------------------------------------------------------------------------*/
/* 
 POSSIBLE IMPLEMENTATION
 -----------------------

 The class SimpleFramePool in file "simple_frame_pool.H/C" describes an
 incomplete vanilla implementation of a frame pool that allocates 
 *single* frames at a time. Because it does allocate one frame at a time, 
 it does not guarantee that a sequence of frames is allocated contiguously.
 This can cause problems.
 
 The class ContFramePool has the ability to allocate either single frames,
 or sequences of contiguous frames. This affects how we manage the
 free frames. In SimpleFramePool it is sufficient to maintain the free 
 frames.
 In ContFramePool we need to maintain free *sequences* of frames.
 
 This can be done in many ways, ranging from extensions to bitmaps to 
 free-lists of frames etc.
 
 IMPLEMENTATION:
 
 One simple way to manage sequences of free frames is to add a minor
 extension to the bitmap idea of SimpleFramePool: Instead of maintaining
 whether a frame is FREE or ALLOCATED, which requires one bit per frame, 
 we maintain whether the frame is FREE, or ALLOCATED, or HEAD-OF-SEQUENCE.
 The meaning of FREE is the same as in SimpleFramePool. 
 If a frame is marked as HEAD-OF-SEQUENCE, this means that it is allocated
 and that it is the first such frame in a sequence of frames. Allocated
 frames that are not first in a sequence are marked as ALLOCATED.
 
 NOTE: If we use this scheme to allocate only single frames, then all 
 frames are marked as either FREE or HEAD-OF-SEQUENCE.
 
 NOTE: In SimpleFramePool we needed only one bit to store the state of 
 each frame. Now we need two bits. In a first implementation you can choose
 to use one char per frame. This will allow you to check for a given status
 without having to do bit manipulations. Once you get this to work, 
 revisit the implementation and change it to using two bits. You will get 
 an efficiency penalty if you use one char (i.e., 8 bits) per frame when
 two bits do the trick.
 
 DETAILED IMPLEMENTATION:
 
 How can we use the HEAD-OF-SEQUENCE state to implement a contiguous
 allocator? Let's look a the individual functions:
 
 Constructor: Initialize all frames to FREE, except for any frames that you 
 need for the management of the frame pool, if any.
 
 get_frames(_n_frames): Traverse the "bitmap" of states and look for a 
 sequence of at least _n_frames entries that are FREE. If you find one, 
 mark the first one as HEAD-OF-SEQUENCE and the remaining _n_frames-1 as
 ALLOCATED.

 release_frames(_first_frame_no): Check whether the first frame is marked as
 HEAD-OF-SEQUENCE. If not, something went wrong. If it is, mark it as FREE.
 Traverse the subsequent frames until you reach one that is FREE or 
 HEAD-OF-SEQUENCE. Until then, mark the frames that you traverse as FREE.
 
 mark_inaccessible(_base_frame_no, _n_frames): This is no different than
 get_frames, without having to search for the free sequence. You tell the
 allocator exactly which frame to mark as HEAD-OF-SEQUENCE and how many
 frames after that to mark as ALLOCATED.
 
 needed_info_frames(_n_frames): This depends on how many bits you need 
 to store the state of each frame. If you use a char to represent the state
 of a frame, then you need one info frame for each FRAME_SIZE frames.
 
 A WORD ABOUT RELEASE_FRAMES():
 
 When we releae a frame, we only know its frame number. At the time
 of a frame's release, we don't know necessarily which pool it came
 from. Therefore, the function "release_frame" is static, i.e., 
 not associated with a particular frame pool.
 
 This problem is related to the lack of a so-called "placement delete" in
 C++. For a discussion of this see Stroustrup's FAQ:
 http://www.stroustrup.com/bs_faq2.html#placement-delete
 
 */
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */
#define MB * (0x1 << 20)
#define KB * (0x1 << 10)

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "cont_frame_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"



/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */


ContFramePool* ContFramePool::pool_head;
ContFramePool* ContFramePool::pool_list;
ContFramePool* ContFramePool::pool_next;





/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   C o n t F r a m e P o o l */
/*--------------------------------------------------------------------------*/

ContFramePool::ContFramePool(unsigned long _base_frame_no,
                             unsigned long _n_frames,
                             unsigned long _info_frame_no,

                             unsigned long _n_info_frames)
{
    
    
    assert(n_frames<= FRAME_SIZE*8);
    
    base_frame_no = _base_frame_no;
    n_frames = _n_frames;   
    info_frame_no= _info_frame_no;
    n_info_frames = _n_info_frames;
    FreeFrame = _n_frames; //initallly all frames are free
    
    if(info_frame_no ==0) {
     bitmap = (unsigned char*) (base_frame_no * FRAME_SIZE); //if info no is zero we start from base frame
     }
     else {
     bitmap = (unsigned char*) (info_frame_no * FRAME_SIZE);
     }
     
    assert((n_frames%8)==0);
    
    for(int i=0; i*8< _n_frames; i++)
    {
    bitmap[i]=0x00;}
    
    if(_info_frame_no == 0) {
        bitmap[0] = 0x80;
        FreeFrame--;
    }
    
    if(ContFramePool::pool_head ==NULL) {
     ContFramePool::pool_list = this;
     ContFramePool::pool_head = this;}
     else {
     pool_list->pool_next= this;
     pool_list =this;
     }
     pool_next = NULL;
     
    
    
    
    Console::puts("Frame Pool is now  initialized\n");
    
    

}

unsigned long ContFramePool::get_frames(unsigned int _n_frames)
{
    // TODO: IMPLEMENTATION NEEEDED!
    
    
    assert(FreeFrame > 0);
    Console::puts("Now get frames\n");
  unsigned int  need_frms = _n_frames;
    
    if(_n_frames>FreeFrame)
    Console::puts("Not possible to get frames\n");
    
    
   
      int srch=0, i_index=0, j_index=0, found= 0;
     unsigned int frame_no = base_frame_no;
    
    for (int i_srch =0; i_srch<n_frames/4;i_srch++){
            
       unsigned char mask = 0xC0;
      
    for (int j_srch = 0; j_srch<4 ;j_srch++)
       {
        if((bitmap[i_srch] & mask)==0)
        {
          if( srch == 1)
           {
           need_frms--;
           }
          else
          {
            frame_no= frame_no +  i_srch*4 + j_srch;     //for every frame we use 2 bits to decide free or alloctd or head of seq
            srch=1;
             i_index = i_srch;
             j_index = j_srch;
             need_frms--;                        
          }
       }
      else    //since we dont get continous free frames we need to re start the search
       {
      if(srch==1) {
     frame_no = base_frame_no;
     need_frms = _n_frames;
     j_index = 0;
     i_index=0;
     srch=0;
     }
     
     }
     
     mask>>2;
     if(need_frms==0)   //if we get continous frames as user wants then set found to 1 
     {
     found =1;
     break;
     }
     }  //for j loop
     
     if(need_frms==0)   
     {
     found =1;
     break;
     }
     
     
     
     } //close the i loop
     
  if(found==0)
  {
  Console::puts("No frame is found that are supposed to be continous\n");
  return 0;
  }
  
  //allocate the frames to its state-if its allocated or head of sequence 
  
   int setthe_frame = _n_frames;
    unsigned char top_mask = 0x40;
    unsigned char inv_mask = 0xC0;
    top_mask = top_mask>>(j_index*2);
    inv_mask = inv_mask>>(j_index*2);
   
    bitmap[i_index] = (bitmap[i_index] & ~inv_mask)| top_mask; // find the frames and set it to 01 --head of seq
    
    j_index++;
    setthe_frame--;

    unsigned char allo_mask = 0xC0;    //after setting the first frame to seq head ,set next to allocated
    allo_mask = allo_mask>>(j_index*2);
    while(setthe_frame > 0 && j_index < 4) {
        bitmap[i_index] = bitmap[i_index] | allo_mask;
        allo_mask = allo_mask>>2;
        setthe_frame--;
        j_index++;
    }
    
    for(int i = i_index + 1; i< n_frames/4; i++) { //set subsequent to allocated
        allo_mask = 0xC0;
        for (int j = 0; j< 4 ; j++) {
            if (setthe_frame == 0) {
                break;
            }
            bitmap[i] = bitmap[i] | allo_mask;
        
            allo_mask = allo_mask>>2;
            setthe_frame--;
        }
        if (setthe_frame ==0){
            break;
        }
    }
    
    
    
    
    if (found == 1) {   //once frames are allocated , remove the corresponding number from total freeframe
        
        FreeFrame -= _n_frames;
        return frame_no;
    } else {
        Console::puts("No frames that are supoosed to be free is found ");
        return 0;
    }
    
    
}

void ContFramePool::mark_inaccessible(unsigned long _base_frame_no,
                                      unsigned long _n_frames)
{
   
   if (_base_frame_no < base_frame_no || base_frame_no + n_frames < _base_frame_no + _n_frames) {
        Console::puts("This is out of range  \n");
    } else {
        
        FreeFrame -= _n_frames;
        int bit_difference = (_base_frame_no - base_frame_no)*2;
        int i_index = bit_difference / 8;
        int j_index = (bit_difference % 8) /2;

        //mark the first as head 

        int setthe_frame = _n_frames;

        unsigned char inacc_mask = 0x80;
        unsigned char inv_mask = 0xC0;
        inacc_mask = inacc_mask>>(j_index*2);
        inv_mask = inv_mask>>(j_index*2);
        while(setthe_frame > 0 && j_index < 4) {
            bitmap[i_index] = (bitmap[i_index] & ~inv_mask) | inacc_mask; // first filter then mask
            inacc_mask = inacc_mask>>2;
            inv_mask = inv_mask>>2;
            setthe_frame--;
            j_index++;
        }

        for(int i = i_index + 1; i< i_index + _n_frames/4; i++) {
            inacc_mask = 0xC0;
            inv_mask = 0xC0;
            for (int j = 0; j< 4 ; j++) {
                if (setthe_frame == 0) {
                    break;
                }
                bitmap[i] = (bitmap[i] & ~inv_mask)| inacc_mask;
                inacc_mask = inacc_mask>>2;
                inv_mask = inv_mask>>2;
                setthe_frame--;
            }
            if (setthe_frame ==0){
                break;
            }
        }
        
    }

  
  
  
  
  
  
}

void ContFramePool::release_frames(unsigned long _first_frame_no)
{
         // this frame belongs to which particular pool
    ContFramePool* current_pool = ContFramePool::pool_head;     //checking if _first_frame_no is present in current pool
    while ( (current_pool->base_frame_no > _first_frame_no || current_pool->base_frame_no + current_pool->n_frames <= _first_frame_no) ) {
        if (current_pool->pool_next == NULL) {
            Console::puts("Frame is not there in any pool, cannot release. \n");
            return;
        } else {
            current_pool = current_pool->pool_next;
        }
    }

    
    unsigned char* bitmap_point = current_pool->bitmap;
    int bit_difference = (_first_frame_no - current_pool->base_frame_no)*2;
    int ithindex = bit_difference / 8;
    int jthindex = (bit_difference % 8) /2;

    unsigned char head_mask = 0x80;
    unsigned char a_mask = 0xC0;
    head_mask = head_mask>>jthindex*2;
    a_mask = a_mask>>jthindex*2;
    if (((bitmap_point[ithindex]^head_mask)&a_mask ) == a_mask) {
        // we have set the head
        bitmap_point[ithindex] = bitmap_point[ithindex] & (~a_mask); 
        jthindex++;
        a_mask = a_mask>>2;
        current_pool->FreeFrame++;

        while (jthindex < 4) {
            if ((bitmap_point[ithindex] & a_mask) == a_mask) {
                bitmap_point[ithindex] = bitmap_point[ithindex] & (~a_mask);
                jthindex++;
                a_mask = a_mask>>2;
                current_pool->FreeFrame++;
            } else {

                return; // release the frames in a sequence 
            }
        } 

        for(int i = ithindex+1; i < (current_pool->base_frame_no + current_pool->n_frames)/4; i++ ) {
            a_mask = 0xC0;
            for (int j = 0; j < 4 ;j++) {
                if ((bitmap_point[i] & a_mask) == a_mask) {
                    bitmap_point[i] = bitmap_point[i] & (~a_mask);
                    a_mask = a_mask>>2;
                    current_pool->FreeFrame++;
                } else {
              

                    return; //  frames  released
                }
            }
        } 


    } else {
        Console::puts("Frame isnt head of sequence, release not possible \n");
    }
   
}

unsigned long ContFramePool::needed_info_frames(unsigned long _n_frames)
{
       return (_n_frames*2)/(8*4 KB) + ((_n_frames*2) % (8*4 KB) > 0 ? 1 : 0);
    
 
}
