/*
     File        : file_system.C

     Author      : Riccardo Bettati
     Modified    : 2021/11/28

     Description : Implementation of simple File System class.
                   Has support for numerical file identifiers.
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */
#define BLOCK_SIZE1 512
#define TOTAL_BLOCK 256 //128KB/BLOCK SIZE = 128KB/512
/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file_system.H"
#include "file.H"
/*--------------------------------------------------------------------------*/
/* CLASS Inode */
/*--------------------------------------------------------------------------*/

/* You may need to add a few functions, for example to help read and store 
   inodes from and to disk. */

/*--------------------------------------------------------------------------*/
/* CLASS FileSystem */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

FileSystem::FileSystem() {
    
    
    
    Console::puts("In file system constructor.\n");
    
 
    
  
}

FileSystem::~FileSystem() {
    Console::puts("unmounting file system\n");
    /* Make sure that the inode list and the free list are saved. */  
   
 
}


/*--------------------------------------------------------------------------*/
/* FILE SYSTEM FUNCTIONS */
/*--------------------------------------------------------------------------*/


bool FileSystem::Mount(SimpleDisk * _disk) {
    Console::puts("mounting file system from disk\n");

    /* Here you read the inode list and the free list into memory */
   disk = _disk;
   
   
  
  Console::puts("Mounting is done\n");  
  return true; 
}

bool FileSystem::Format(SimpleDisk * _disk, unsigned int _size) { // static!
    Console::puts("formatting disk\n");
    /* Here you populate the disk with an initialized (probably empty) inode list
       and a free list. Make sure that blocks used for the inodes and for the free list
       are marked as used, otherwise they may get overwritten. */
       
       //memset(buffer_disk,0,512);
       //initalize the 0th block which is used to store inode list 
       unsigned char buffer_disk[512];
      memset(buffer_disk,0,BLOCK_SIZE1);
     
      
     _disk->read(0,(unsigned char*)buffer_disk);   //reading 0th block and storing buffer disk 
     Inode * inodbuff = (Inode *)buffer_disk; 
    for (int k = 0; k < MAX_INODES; k++)
    {
        inodbuff->id = -1; 
        inodbuff->start_point = -1; 
        k++;
    }
    
    _disk->write(0,(unsigned char*)inodbuff); //writing the 0th block 
    
    
    
    unsigned char buffer2[512];
   memset(buffer2,0,BLOCK_SIZE1);  //update all the blocks from 2nd to rest as free since we are formatting disk
   // clearing all data in buffer 
   
   
    for (int i = 2; i < TOTAL_BLOCK; i++)
        _disk->write(i,buffer2);
        
        //initalize the first block which has free block list 
        
       
        memset(buffer2,0,BLOCK_SIZE1);
        _disk->read(1,(unsigned char*)buffer2);
        
        buffer2[0]= 'N'; //my first 2 blocks are not free Nsince im using to store inode and freebllock info 
        buffer2[1]= 'N';
    for (int i = 2; i < TOTAL_BLOCK; i++)
    {
         buffer2[i] = 'F'; //mark as no data
   
    }
    
    _disk->write(1,( unsigned char*)buffer2); //write back 1st block info 
        
      Console::puts("Formatting done\n");  
        
return true;
       
   
}

Inode * FileSystem::LookupFile(int _file_id) {
    Console::puts("looking up file with id = "); Console::puti(_file_id); Console::puts("\n");
    /* Here you go through the inode list to find the file. */
    unsigned char buffer_disk[512];
    memset(buffer_disk,0,512);
    FileSystem::disk->read(0, (unsigned char*)buffer_disk);
    int found =0;
    for(int l = 0;l<MAX_INODES;l++){
    
    if(buffer_disk[l] == _file_id)
    {
    
    Console::puts("File has been found \n ");
    found =1;
    break;
    }
   
    
    }
     Inode * inodbuff = (Inode *)buffer_disk;
    if (found == 1)
    return inodbuff;
   // else 
    //return null;
    
    
    
}

bool FileSystem::CreateFile(int _file_id) {
    Console::puts("creating file with id:"); Console::puti(_file_id); Console::puts("\n");
    /* Here you check if the file exists already. If so, throw an error.
       Then get yourself a free inode and initialize all the data needed for the
       new file. After this function there will be a new file on disk. */
    
    
   //memset(buffer_disk,0,512);
    //Inode *inodesfindfree = inodes;
    //FileSystem::disk->read(0, (unsigned char*)inodes);
    
    
     unsigned char buffer_disk[512];
      memset(buffer_disk,0,BLOCK_SIZE1);
     
      unsigned char* tmp;
     FileSystem::disk->read(0,(unsigned char*)inodes);   //reading 0th block and storing buffer disk 
   
    inodes = (Inode *)buffer_disk;
   // int found =0;
  for(int l = 0;l<MAX_INODES;l++){
    
    if(inodes->id == _file_id)
   {
    
   return false;
   }
    inodes++;
    }
    
    Console::puts("File create line1\n");
    //get free inode
    int i=0;
    unsigned char buffer3[512];
      memset(buffer3,0,512);
    FileSystem::disk->read(0, (unsigned char*)buffer3);
    Inode * inodbuffer = (Inode *)buffer3;
    
    
    while(i < MAX_INODES){
    
    if (inodbuffer->id==-1){
    
   break;
     
    }
    *inodbuffer++;
    i++;
    }
    
    //we got the new  freeinode now we intilalize the data needed
    
    
    
     //get free block;
     
      int free_blockno;
      unsigned char buffer4[512];
      memset(buffer4,0,512);
      FileSystem::disk->read(1, buffer4);
      
      
    
      for (int m = 0; m < BLOCK_SIZE1; m++)
    {
       
        if(buffer4[m]=='F'){
        
        free_blockno = m;
        break;
       
        }

    }
    
   inodes->id = _file_id;
   inodes->start_point = free_blockno;
   // unsigned char buffdat[512] = 
    disk->write(0,(unsigned char*)inodes); //update the entry in disk 
    
    
    Console::puts("File has been created successfully\n");
    return true;
}

bool FileSystem::DeleteFile(int _file_id) {
    Console::puts("deleting file with id:"); Console::puti(_file_id); Console::puts("\n");
    /* First, check if the file exists. If not, throw an error. 
       Then free all blocks that belong to the file and delete/invalidate 
       (depending on your implementation of the inode list) the inode. */
    
    
     int present = 0; 
     unsigned char buffer_disk[512];  
     memset(buffer_disk,0,512);
     
     FileSystem::disk->read(0, buffer_disk);;
     Inode * inodedel = (Inode *)buffer_disk;
   
    
    
    for(int i =0;i< MAX_INODES; i++)
    {
    
     if(inodedel->id == _file_id)
      {
       present = 1;
       break;
       
      }
      
      
      *inodedel++;
    }
    
    if(present == 0)
    return false;
    
    int block_noinfo = inodedel->start_point; 
     inodedel->id = -1; 
     inodedel->start_point = 0;
     FileSystem::disk->write(0, (unsigned char*)inodedel); //update inode  in disk
     
     //update the free block list
     
     unsigned char buffer2[512];
      memset(buffer2,0,BLOCK_SIZE1);
      FileSystem::disk->read(1, buffer2);
      
      buffer2[block_noinfo] ='F';
      
     disk->write(1,buffer2);
   
    memset(buffer2,0,BLOCK_SIZE1);  //the data block is also cleared
    
    disk->write(block_noinfo,buffer2);
   Console::puts("FIle has been deleted from disk\n");
  return true;

}

