/*
     File        : file.C

     Author      : Riccardo Bettati
     Modified    : 2021/11/28

     Description : Implementation of simple File class, with support for
                   sequential read/write operations.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file.H"
#include "file_system.H"
/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR */
/*--------------------------------------------------------------------------*/




File::File(FileSystem *_fs, int _id) {
    Console::puts("Opening file.\n");
    
   FS = _fs;
   _id = -1;
    current_position = 0;
    
    Inode *IN = FS->LookupFile(_id);
    
   int block_number= IN->start_point;
    
    
}

File::~File() {
    Console::puts("Closing file.\n");
    /* Make sure that you write any cached data to disk. */
    /* Also make sure that the inode in the inode list is updated. */
    
    
    
    
}

/*--------------------------------------------------------------------------*/
/* FILE FUNCTIONS */
/*--------------------------------------------------------------------------*/

int File::Read(unsigned int _n, char *_buf) {
    Console::puts("reading from file\n");
    
    
    
    
    
    
   
// unsigned  char newbuffer[512];
 //mmset(newbuffer,0,512);
 
   FS->disk->read(block_number, block_cache);
    
  int read_Data=0;
  int data_to_read = _n;
  
  int i=0;
  while(!EoF() && data_to_read >0 ){
  
  
  _buf[read_Data] = block_cache[i];
  read_Data++;
  i++;
  
  data_to_read--;
  }
  
  Console::puts("Reading done\n");  
return read_Data;
   
   
   
}

int File::Write(unsigned int _n, const char *_buf) {
    Console::puts("writing to file\n");
    
    
   // unsigned char writebuffer[512];
    //memset(writebuffer,0,512);
    FS->disk->read(block_number, block_cache);
    
    int writen_data=0;;
    int data_to_write = _n;
    int j=0;
    
    while(!EoF() && data_to_write >0 ){
    
    block_cache[j] = _buf[j];
    j++;
    
    writen_data++;
    data_to_write--;
    
    }
    FS->disk->write(block_number,block_cache);
    
    
    Console::puts("Writing has been done\n");
    
    return writen_data;
}

void File::Reset() {
    Console::puts("resetting file\n");
   current_position = 0;
   
}

bool File::EoF() {
    Console::puts("checking for EoF\n");
    
    if (current_position <= BLOCK_SIZE1-1)
    return false;
    else 
    return true;
    
    
    
    
    
    
    
    
}
